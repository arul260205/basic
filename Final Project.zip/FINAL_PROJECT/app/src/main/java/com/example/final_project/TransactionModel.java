package com.example.final_project;

import java.io.Serializable;

public class TransactionModel implements Serializable {
    private String id;
    private String amount;
    private String category;
    private String date;
    private String description;

    public TransactionModel() {
        // Required for Firebase
    }

    public TransactionModel(String id, String amount, String category, String date, String description) {
        this.id = id;
        this.amount = amount;
        this.category = category;
        this.date = date;
        this.description = description;
    }

    public String getId() {
        return id == null ? "" : id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAmount() {
        return amount == null ? "0" : amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCategory() {
        return category == null ? "Unknown" : category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDate() {
        return date == null ? "Unknown Date" : date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description == null ? "No Description" : description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
