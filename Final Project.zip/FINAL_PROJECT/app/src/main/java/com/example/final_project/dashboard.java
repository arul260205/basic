package com.example.final_project;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class dashboard extends AppCompatActivity {

    private TextView textViewSaldo, textViewPengeluaran;
    private DatabaseReference mDatabase;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Firebase reference
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Referencing UI elements
        textViewSaldo = findViewById(R.id.textViewSaldo);
        textViewPengeluaran = findViewById(R.id.textViewPengeluaran);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setOnItemSelectedListener(this::onNavigationItemSelected);

        // Get transactions data from Firebase
        fetchTransactionData();
    }

    private void fetchTransactionData() {
        mDatabase.child("transactions").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                double totalSaldo = 0;
                double totalPengeluaran = 0;

                for (DataSnapshot transactionSnapshot : dataSnapshot.getChildren()) {
                    TransactionModel transaction = transactionSnapshot.getValue(TransactionModel.class);
                    if (transaction != null) {
                        try {
                            double amount = Double.parseDouble(transaction.getAmount());
                            if ("Pengeluaran".equals(transaction.getCategory())) {
                                totalPengeluaran += amount;
                            } else {
                                totalSaldo += amount;
                            }
                        } catch (NumberFormatException e) {
                            Toast.makeText(dashboard.this, "Invalid amount format in data.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                // Update UI with values
                textViewSaldo.setText("Saldo: Rp " + totalSaldo);
                textViewPengeluaran.setText("Total Pengeluaran: Rp " + totalPengeluaran);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(dashboard.this, "Failed to load data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean onNavigationItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.home) {
            // Navigate to About Activity
            startActivity(new Intent(dashboard.this, about.class));
            return true;
        } else if (itemId == R.id.finance) {
            // Navigate to Keuangan Activity
            startActivity(new Intent(dashboard.this, transaction.class));
            return true;
        } else if (itemId == R.id.schedule) {
            // Navigate to Jadwal Activity
            startActivity(new Intent(dashboard.this, calendar.class));
            return true;
        } else if (itemId == R.id.reports) {
            // Navigate to Laporan Activity
            startActivity(new Intent(dashboard.this, monthly_report.class));
            return true;
        } else {
            return false;
        }
    }
}
