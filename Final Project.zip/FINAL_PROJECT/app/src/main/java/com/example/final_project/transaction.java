package com.example.final_project;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class transaction extends AppCompatActivity {

    private EditText etAmount, etDescription;
    private Spinner spCategory;
    private Button btnSaveTransaction;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        // Initialize Firebase reference
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Referencing UI elements
        etAmount = findViewById(R.id.etAmount);
        etDescription = findViewById(R.id.etDescription);
        spCategory = findViewById(R.id.spCategory);
        btnSaveTransaction = findViewById(R.id.btnSaveTransaction);

        // Set up Spinner with category options
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.category_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(adapter);

        // Save transaction to Firebase when button is clicked
        btnSaveTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTransaction();
            }
        });
    }

    private void saveTransaction() {
        String amount = etAmount.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String category = spCategory.getSelectedItem().toString();

        // Validate input fields
        if (amount.isEmpty() || description.isEmpty()) {
            Toast.makeText(transaction.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a unique ID for the transaction
        String transactionId = mDatabase.child("transactions").push().getKey();

        // Get the current date
        String currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        // Create a TransactionModel object
        TransactionModel transaction = new TransactionModel(transactionId, amount, description, category, currentDate);

        // Save the transaction to Firebase
        if (transactionId != null) {
            mDatabase.child("transactions").child(transactionId).setValue(transaction)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(transaction.this, "Transaction Saved", Toast.LENGTH_SHORT).show();
                            finish(); // Close the activity and return to the previous screen
                        } else {
                            Toast.makeText(transaction.this, "Failed to save transaction", Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            Toast.makeText(this, "Error generating transaction ID", Toast.LENGTH_SHORT).show();
        }
    }
}
