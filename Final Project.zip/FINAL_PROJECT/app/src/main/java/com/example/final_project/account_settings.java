package com.example.final_project;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class account_settings extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnCreateAccount;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_settings);

        // Inisialisasi Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnCreateAccount = findViewById(R.id.btnSaveSettings);

        btnCreateAccount.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (TextUtils.isEmpty(email)) {
                Toast.makeText(account_settings.this, "Email tidak boleh kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            if (TextUtils.isEmpty(password)) {
                Toast.makeText(account_settings.this, "Password tidak boleh kosong", Toast.LENGTH_SHORT).show();
                return;
            }

            if (password.length() < 6) {
                Toast.makeText(account_settings.this, "Password minimal 6 karakter", Toast.LENGTH_SHORT).show();
                return;
            }

            // Buat akun baru dengan email dan password
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(account_settings.this, "Akun berhasil dibuat", Toast.LENGTH_SHORT).show();
                            // Arahkan ke halaman login setelah akun dibuat
                            Intent intent = new Intent(account_settings.this, login.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(account_settings.this, "Gagal membuat akun: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}